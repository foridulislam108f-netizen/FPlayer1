# FPlayer (Android)
FPlayer HTML5 অডিও/ভিডিও প্লেয়ারের Android WebView অ্যাপ।
GitHub-এ push করলেই Actions APK বানায় (Releases ট্যাবে `FPlayer.apk`)।
প্লেয়ার বদলাতে: `app/src/main/assets/index.html` replace করুন।

package com.fplayer.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.*
import android.widget.FrameLayout
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class MainActivity : android.app.Activity() {

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var queuedUris: List<Uri>? = null
    private var openWithUri: Uri? = null
    private var openWithName: String? = null
    private var pageLoaded = false
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    // সর্বশেষ বাছাই করা ফাইলের URI (WebView না পারলে ব্যাকআপ প্লেয়ারে খুলতে লাগে)
    private var pickedUris: List<Uri> = emptyList()
    private var nativePlayer: NativePlayerView? = null

    companion object {
        private const val REQ_FILE = 101
        private const val REQ_TREE = 102
        private const val REQ_NOTIF = 103
        private const val REQ_MEDIA = 104
        private const val HOST = "https://appassets.androidplatform.net"
        private const val START_URL = "$HOST/assets/index.html"
    }

    // ---- ব্লব ডাউনলোড (স্ক্রিনশট) অ্যান্ড্রয়েডে সেভ করার জন্য JS shim ----
    private val blobShim = """
        (function(){
          if (window.__fpShim) return; window.__fpShim = true;
          var orig = HTMLAnchorElement.prototype.click;
          HTMLAnchorElement.prototype.click = function(){
            try {
              if (this.download && this.href && this.href.indexOf('blob:') === 0 && window.AndroidBridge) {
                var name = this.download;
                fetch(this.href).then(function(r){return r.blob();}).then(function(b){
                  var fr = new FileReader();
                  fr.onloadend = function(){
                    var s = String(fr.result); 
                    AndroidBridge.saveFile(name, b.type || 'application/octet-stream', s.substring(s.indexOf(',')+1));
                  };
                  fr.readAsDataURL(b);
                });
                return;
              }
            } catch(e) {}
            return orig.apply(this, arguments);
          };
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(root)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                allowFileAccess = false
                allowContentAccess = true
                loadWithOverviewMode = true
                useWideViewPort = true
                setSupportZoom(false)
                builtInZoomControls = false
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            }
            addJavascriptInterface(Bridge(), "AndroidBridge")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    assetLoader.shouldInterceptRequest(request.url)

                override fun onPageFinished(view: WebView, url: String?) {
                    view.evaluateJavascript(blobShim, null)
                    pageLoaded = true
                    deliverOpenWith()
                }

                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val u = request.url
                    if (u.host == "appassets.androidplatform.net") return false
                    return try {
                        startActivity(Intent(Intent.ACTION_VIEW, u)); true
                    } catch (e: Exception) { true }
                }
            }
            webChromeClient = FPChromeClient()
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        root.addView(webView)

        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl(START_URL)

        askNotificationPermissionThenStartService()
        handleViewIntent(intent)
    }

    // ---------- ব্যাকগ্রাউন্ড সার্ভিস ----------
    private fun askNotificationPermissionThenStartService() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
        startKeepAlive()
    }

    private fun startKeepAlive() {
        try {
            val i = Intent(this, KeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (_: Exception) { }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_NOTIF) startKeepAlive()
        if (code == REQ_MEDIA) {
            val ok = hasMediaPermission()
            runOnUiThread { webView.evaluateJavascript("window.fpOnMediaPerm && window.fpOnMediaPerm($ok)", null) }
        }
    }

    // ---------- "Open with" দিয়ে আসা ফাইল ----------
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleViewIntent(intent)
    }

    private fun handleViewIntent(i: Intent?) {
        val uri = i?.data
        if (i?.action == Intent.ACTION_VIEW && uri != null) {
            openWithUri = uri
            openWithName = queryName(uri) ?: uri.lastPathSegment ?: "media"
            deliverOpenWith()
        }
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) { null }

    // পেজ লোড হয়ে গেলে "Open with" ফাইলের নাম ওয়েবপেজে পাঠায় (প্লে বাটন দেখানোর জন্য)
    private fun deliverOpenWith() {
        val n = openWithName ?: return
        if (!pageLoaded) return
        webView.evaluateJavascript("window.fpOpenWith && window.fpOpenWith(" + JSONObject.quote(n) + ")", null)
    }

    // ---------- Chrome client: ফাইল চুজার + ফুলস্ক্রিন ----------
    inner class FPChromeClient : WebChromeClient() {

        override fun onShowFileChooser(
            wv: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams
        ): Boolean {
            // অ্যাপের নিজস্ব মিডিয়া লিস্ট থেকে বাছাই করা ফাইল সরাসরি পাঠানো (চুজার না খুলে)
            val queued = queuedUris
            if (queued != null) {
                queuedUris = null
                pickedUris = queued
                callback.onReceiveValue(queued.toTypedArray())
                return true
            }

            fileCallback?.onReceiveValue(null)
            fileCallback = callback

            // mode 2 = ফোল্ডার আপলোড (webkitdirectory)
            if (params.mode == 2) {
                return try {
                    startActivityForResult(
                        Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                        ), REQ_TREE
                    )
                    true
                } catch (e: Exception) {
                    fileCallback = null; callback.onReceiveValue(null); false
                }
            }

            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                val types = params.acceptTypes?.filter { it.isNotBlank() }?.flatMap { it.split(",") }
                    ?.map { it.trim() }?.filter { it.isNotEmpty() }
                if (types.isNullOrEmpty()) {
                    type = "*/*"
                } else if (types.size == 1) {
                    type = types[0]
                } else {
                    type = "*/*"
                    val extra = ArrayList(types)
                    if (types.any { it.startsWith("audio") || it.startsWith("video") }) {
                        // mkv/ogg/rm ইত্যাদি অনেক ফাইলের MIME অন্যরকম বা অজানা থাকে
                        extra.addAll(listOf("application/octet-stream", "application/x-matroska", "application/ogg",
                            "application/vnd.rn-realmedia", "application/vnd.rn-realmedia-vbr", "application/mxf",
                            "application/x-mpegURL", "application/vnd.apple.mpegurl", "application/mp4"))
                    }
                    putExtra(Intent.EXTRA_MIME_TYPES, extra.distinct().toTypedArray())
                }
                if (params.mode == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
            }
            return try {
                startActivityForResult(Intent.createChooser(intent, "Select media"), REQ_FILE)
                true
            } catch (e: Exception) {
                fileCallback = null; callback.onReceiveValue(null); false
            }
        }

        override fun onShowCustomView(view: View, cb: CustomViewCallback) {
            if (customView != null) { cb.onCustomViewHidden(); return }
            customView = view
            customViewCallback = cb
            view.setBackgroundColor(Color.BLACK)
            root.addView(view, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            webView.visibility = View.GONE
            enterImmersive()
        }

        override fun onHideCustomView() {
            val v = customView ?: return
            root.removeView(v)
            customView = null
            customViewCallback?.onCustomViewHidden()
            customViewCallback = null
            webView.visibility = View.VISIBLE
            exitImmersive()
        }

        override fun onPermissionRequest(request: PermissionRequest) {
            request.deny()
        }
    }

    @Suppress("DEPRECATION")
    private fun enterImmersive() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    @Suppress("DEPRECATION")
    private fun exitImmersive() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    // ---------- ফাইল/ফোল্ডার রেজাল্ট ----------
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val cb = fileCallback ?: return
        fileCallback = null

        when (requestCode) {
            REQ_FILE -> {
                val res = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                if (res != null) pickedUris = res.toList()
                cb.onReceiveValue(res)
            }
            REQ_TREE -> {
                val tree = data?.data
                if (resultCode != RESULT_OK || tree == null) { cb.onReceiveValue(null); return }
                try {
                    contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {}
                Thread {
                    val list = ArrayList<Uri>()
                    try {
                        collectMedia(tree, DocumentsContract.getTreeDocumentId(tree), list)
                    } catch (_: Exception) {}
                    runOnUiThread {
                        if (list.isEmpty()) {
                            Toast.makeText(this, "No audio/video files found", Toast.LENGTH_SHORT).show()
                            cb.onReceiveValue(null)
                        } else { pickedUris = list; cb.onReceiveValue(list.toTypedArray()) }
                    }
                }.start()
            }
            else -> cb.onReceiveValue(null)
        }
    }

    private fun collectMedia(tree: Uri, docId: String, out: MutableList<Uri>) {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val proj = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME
        )
        contentResolver.query(children, proj, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                val mime = c.getString(1) ?: ""
                val name = (c.getString(2) ?: "").lowercase()
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    collectMedia(tree, id, out)
                } else if (mime.startsWith("audio/") || mime.startsWith("video/") ||
                    name.matches(Regex(".*\\.(mp3|m4a|m4b|aac|wav|wave|flac|alac|ogg|oga|opus|wma|amr|3ga|mka|ape|wv|tta|ac3|eac3|dts|dsf|dff|aif|aiff|aifc|au|caf|mp2|mpa|spx|weba|mp4|m4v|mkv|webm|avi|mov|qt|3gp|3g2|flv|f4v|wmv|asf|mpg|mpeg|mpe|m2v|ts|m2ts|mts|vob|mxf|rm|rmvb|divx|ogv|ogm|dv|hevc|h264|m3u8)$"))
                ) {
                    out.add(DocumentsContract.buildDocumentUriUsingTree(tree, id))
                }
            }
        }
    }

    // ---------- ফোনের সব অডিও/ভিডিও ফাইলের তালিকা ----------
    private fun hasMediaPermission(): Boolean =
        if (Build.VERSION.SDK_INT >= 33)
            checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
        else
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun queryMedia(video: Boolean, out: JSONArray) {
        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val folderCol = if (Build.VERSION.SDK_INT >= 29) MediaStore.MediaColumns.RELATIVE_PATH else MediaStore.MediaColumns.DATA
        val proj = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED,
            folderCol,
            "duration"
        )
        val sel = if (video) null else
            "is_ringtone=0 AND is_notification=0 AND is_alarm=0"
        contentResolver.query(base, proj, sel, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val name = c.getString(1) ?: continue
                var folder = c.getString(4) ?: ""
                if (Build.VERSION.SDK_INT < 29) folder = folder.substringBeforeLast('/', "").substringAfterLast('/')
                else folder = folder.trimEnd('/')
                out.put(JSONObject().apply {
                    put("u", android.content.ContentUris.withAppendedId(base, id).toString())
                    put("n", name)
                    put("v", video)
                    put("s", c.getLong(2))
                    put("m", c.getLong(3))
                    put("f", folder)
                    put("d", c.getLong(5))
                })
            }
        }
    }

    // ---------- স্ক্রিনশট সেভ ----------
    inner class Bridge {
        @JavascriptInterface
        fun hasMediaPermission(): Boolean = this@MainActivity.hasMediaPermission()

        // ---------- সেটিংস: স্ক্রিন অরিয়েন্টেশন (WebView-র screen.orientation.lock এখানে চলে না) ----------
        @JavascriptInterface
        fun setOrientation(mode: String) {
            runOnUiThread {
                requestedOrientation = when (mode) {
                    "landscape" -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    "portrait" -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    "current" -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LOCKED
                    else -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                }
            }
        }

        // ---------- সেটিংস: ক্যাশ মোছা (সেটিংস/সেভ করা পজিশন থাকবে) ----------
        @JavascriptInterface
        fun clearCache() {
            runOnUiThread {
                try { webView.clearCache(true) } catch (_: Exception) {}
                try { cacheDir.listFiles()?.forEach { it.deleteRecursively() } } catch (_: Exception) {}
                try { externalCacheDir?.listFiles()?.forEach { it.deleteRecursively() } } catch (_: Exception) {}
            }
        }

        @JavascriptInterface
        fun requestMediaPermission() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(
                        Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO), REQ_MEDIA)
                } else {
                    requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQ_MEDIA)
                }
            }
        }

        @JavascriptInterface
        fun listMedia(): String {
            val out = JSONArray()
            try { queryMedia(true, out) } catch (_: Exception) {}
            try { queryMedia(false, out) } catch (_: Exception) {}
            return out.toString()
        }

        // WebView ফাইলটা চালাতে না পারলে ব্যাকআপ প্লেয়ারে (Media3) খোলে
        @JavascriptInterface
        fun playNative(name: String): Boolean {
            val list = pickedUris
            if (list.isEmpty()) return false
            var idx = list.indexOfFirst { (queryName(it) ?: it.lastPathSegment) == name }
            if (idx < 0) idx = if (list.size == 1) 0 else return false
            runOnUiThread { openNativePlayer(list, idx) }
            return true
        }

        @JavascriptInterface
        fun queueOpenWith(): Boolean {
            val u = openWithUri ?: return false
            queuedUris = listOf(u)
            return true
        }

        @JavascriptInterface
        fun queueSelection(json: String) {
            val arr = JSONArray(json)
            val list = ArrayList<Uri>(arr.length())
            for (i in 0 until arr.length()) list.add(Uri.parse(arr.getString(i)))
            queuedUris = list
        }

        @JavascriptInterface
        fun saveFile(name: String, mime: String, base64: String) {
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, safe)
                        put(MediaStore.MediaColumns.MIME_TYPE, mime)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/FPlayer")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                } else {
                    val dir = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "FPlayer").apply { mkdirs() }
                    FileOutputStream(File(dir, safe)).use { it.write(bytes) }
                }
            } catch (_: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Save failed", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    // ---------- ব্যাকআপ প্লেয়ার (Media3 ExoPlayer) ----------
    private fun openNativePlayer(list: List<Uri>, index: Int) {
        closeNativePlayer()
        try {
            val v = NativePlayerView(this, list, index) { closeNativePlayer() }
            nativePlayer = v
            root.addView(v, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            webView.evaluateJavascript("try{pauseMedia()}catch(e){}", null)
        } catch (e: Throwable) {
            nativePlayer = null
            Toast.makeText(this, "Player could not start", Toast.LENGTH_SHORT).show()
        }
    }

    private fun closeNativePlayer() {
        val v = nativePlayer ?: return
        nativePlayer = null
        try { v.release() } catch (_: Exception) {}
        root.removeView(v)
    }

    // ---------- লাইফসাইকেল ----------
    // জেনেবুঝে webView.onPause() কল করা হয়নি — তাই ব্যাকগ্রাউন্ডে অডিও চলতে থাকে।
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (nativePlayer != null) { closeNativePlayer(); return }
        if (customView != null) {
            webView.webChromeClient?.onHideCustomView()
            return
        }
        // খোলা প্যানেল/লিস্ট থাকলে আগে সেটা বন্ধ হবে; কিছু খোলা না থাকলে অ্যাপ ব্যাকগ্রাউন্ডে যাবে, প্লেব্যাক চলতে থাকবে
        webView.evaluateJavascript("(window.fpHandleBack && window.fpHandleBack()) === true") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    override fun onDestroy() {
        if (isFinishing) {
            stopService(Intent(this, KeepAliveService::class.java))
        }
        closeNativePlayer()
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        super.onDestroy()
    }
}

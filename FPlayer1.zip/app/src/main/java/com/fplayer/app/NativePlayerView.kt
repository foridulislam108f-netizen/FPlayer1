package com.fplayer.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer

/**
 * Media3 ExoPlayer দিয়ে চলা ব্যাকআপ প্লেয়ার (ছোট সাইজ, ফোনের হার্ডওয়্যার ডিকোডার ব্যবহার করে)।
 * WebView যে ফাইল চালাতে পারে না (MKV, FLV, TS, বিরল কোডেক/HEVC ইত্যাদি) সেগুলো এখানে চলে।
 * MainActivity-র উপরে overlay হিসেবে বসে, তাই ফাইলের permission আলাদা করে পাঠাতে হয় না।
 */
@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
class NativePlayerView(
    context: Context,
    private val uris: List<Uri>,
    startIndex: Int,
    private val onClose: () -> Unit
) : FrameLayout(context) {

    private val player: ExoPlayer = ExoPlayer.Builder(
        context,
        DefaultRenderersFactory(context).setEnableDecoderFallback(true)
    ).build()

    private val videoHolder = FrameLayout(context)
    private val surface = SurfaceView(context)
    private val titleView = TextView(context)
    private val subtitleView = TextView(context)
    private val topBar = LinearLayout(context)
    private val bottomBar = LinearLayout(context)
    private val seek = SeekBar(context)
    private val timeView = TextView(context)
    private val playBtn = TextView(context)
    private val nameView = TextView(context)

    private val ui = Handler(Looper.getMainLooper())
    private var dragging = false
    private var released = false
    private var videoRatio = 0f
    private val hideRunnable = Runnable { showControls(false) }
    private val tick = object : Runnable {
        override fun run() {
            if (released) return
            updateProgress()
            ui.postDelayed(this, 500)
        }
    }

    init {
        setBackgroundColor(Color.BLACK)
        keepScreenOn = true
        isClickable = true

        videoHolder.addView(surface, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        addView(videoHolder, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        videoHolder.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fitVideo() }

        // অডিও ফাইলে ছবি থাকে না: ফাইলের নাম মাঝখানে দেখানো হয়
        titleView.apply {
            setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            setPadding(dp(24), 0, dp(24), 0)
        }
        addView(titleView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        // সাবটাইটেল
        subtitleView.apply {
            setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
            setPadding(dp(16), 0, dp(16), dp(96))
        }
        addView(subtitleView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        // উপরের বার: ব্যাক + নাম
        topBar.apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.argb(150, 0, 0, 0))
            setPadding(dp(8), dp(28), dp(8), dp(8))
        }
        nameView.apply { setTextColor(Color.WHITE); textSize = 14f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }
        topBar.addView(button("←", 22f) { close() })
        topBar.addView(nameView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(topBar, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        // নিচের বার: সিক + বাটন
        bottomBar.apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(150, 0, 0, 0))
            setPadding(dp(12), dp(8), dp(12), dp(16))
        }
        val seekRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        timeView.apply { setTextColor(Color.WHITE); textSize = 12f; text = "00:00 / 00:00" }
        seek.max = 1000
        seekRow.addView(seek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        seekRow.addView(timeView)
        val btnRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        playBtn.apply { text = "❚❚"; setTextColor(Color.WHITE); textSize = 22f; gravity = Gravity.CENTER; setPadding(dp(18), dp(8), dp(18), dp(8)); setOnClickListener { togglePlay() } }
        btnRow.addView(button("⏮", 20f) { step(-1) })
        btnRow.addView(button("−10", 15f) { seekBy(-10_000L) })
        btnRow.addView(playBtn)
        btnRow.addView(button("+10", 15f) { seekBy(10_000L) })
        btnRow.addView(button("⏭", 20f) { step(1) })
        btnRow.addView(button("♪", 20f) { cycleAudio() })
        btnRow.addView(button("CC", 15f) { cycleSubtitle() })
        bottomBar.addView(seekRow)
        bottomBar.addView(btnRow)
        addView(bottomBar, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val d = duration()
                if (fromUser && d > 0) timeView.text = fmt(d * p / 1000) + " / " + fmt(d)
            }
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true; ui.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) {
                dragging = false
                val d = duration()
                if (d > 0) player.seekTo(d * seek.progress / 1000)
                scheduleHide()
            }
        })

        // ছবিতে ট্যাপ করলে কন্ট্রোল দেখায়/লুকায়
        videoHolder.setOnClickListener { showControls(topBar.visibility != View.VISIBLE) }

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playBtn.text = if (isPlaying) "❚❚" else "▶" }
            override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_ENDED) close() }
            override fun onMediaItemTransition(item: MediaItem?, reason: Int) { showName() }
            override fun onVideoSizeChanged(size: VideoSize) {
                videoRatio = if (size.height > 0) size.width * size.pixelWidthHeightRatio / size.height else 0f
                fitVideo()
                titleView.visibility = if (size.width > 0) View.GONE else View.VISIBLE
            }
            override fun onCues(cueGroup: CueGroup) {
                subtitleView.text = cueGroup.cues.mapNotNull { it.text }.joinToString("\n")
            }
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(context, "এই ফাইলটি চালানো যাচ্ছে না", Toast.LENGTH_SHORT).show()
                if (player.hasNextMediaItem()) { player.seekToNextMediaItem(); player.prepare(); player.play() }
                else close()
            }
        })

        player.setVideoSurfaceView(surface)
        player.setMediaItems(uris.map { MediaItem.fromUri(it) }, index0(startIndex), 0L)
        player.prepare()
        player.playWhenReady = true
        showName()
        scheduleHide()
        ui.post(tick)
    }

    private fun index0(i: Int) = i.coerceIn(0, (uris.size - 1).coerceAtLeast(0))

    // ---------- ছবির মাপ: অনুপাত ঠিক রেখে মাঝখানে বসানো ----------
    private fun fitVideo() {
        val w = videoHolder.width; val h = videoHolder.height
        if (w <= 0 || h <= 0) return
        val lp = surface.layoutParams as LayoutParams
        if (videoRatio <= 0f) { lp.width = ViewGroup.LayoutParams.MATCH_PARENT; lp.height = ViewGroup.LayoutParams.MATCH_PARENT }
        else if (w.toFloat() / h > videoRatio) { lp.height = h; lp.width = (h * videoRatio).toInt() }
        else { lp.width = w; lp.height = (w / videoRatio).toInt() }
        lp.gravity = Gravity.CENTER
        surface.layoutParams = lp
    }

    // ---------- প্লেব্যাক ----------
    private fun showName() {
        val n = displayName(uris[index0(player.currentMediaItemIndex)])
        nameView.text = n
        titleView.text = n
        subtitleView.text = ""
    }

    private fun step(d: Int) {
        if (d > 0 && player.hasNextMediaItem()) player.seekToNextMediaItem()
        else if (d < 0 && player.currentPosition > 3000) player.seekTo(0)
        else if (d < 0 && player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
        scheduleHide()
    }

    private fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
        scheduleHide()
    }

    private fun seekBy(ms: Long) {
        val d = duration()
        val t = (player.currentPosition + ms).coerceAtLeast(0L)
        player.seekTo(if (d > 0) t.coerceAtMost(d - 500) else t)
        scheduleHide()
    }

    private fun duration(): Long = player.duration.let { if (it == C.TIME_UNSET || it < 0) 0L else it }

    // ---------- অডিও / সাবটাইটেল ট্র্যাক ----------
    private fun trackName(f: androidx.media3.common.Format, fallback: String, i: Int): String =
        f.label ?: f.language?.let { java.util.Locale(it).displayLanguage } ?: "$fallback ${i + 1}"

    private fun cycleAudio() {
        val opts = ArrayList<Triple<androidx.media3.common.Tracks.Group, Int, Boolean>>()
        player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }.forEach { g ->
            for (i in 0 until g.length) if (g.isTrackSupported(i)) opts.add(Triple(g, i, g.isTrackSelected(i)))
        }
        if (opts.size < 2) { Toast.makeText(context, "আর কোনো অডিও ট্র্যাক নেই", Toast.LENGTH_SHORT).show(); return }
        val cur = opts.indexOfFirst { it.third }
        val next = opts[(cur + 1) % opts.size]
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(next.first.mediaTrackGroup, next.second)).build()
        Toast.makeText(context, trackName(next.first.getTrackFormat(next.second), "Audio", opts.indexOf(next)), Toast.LENGTH_SHORT).show()
        scheduleHide()
    }

    private fun cycleSubtitle() {
        val opts = ArrayList<Triple<androidx.media3.common.Tracks.Group, Int, Boolean>>()
        player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }.forEach { g ->
            for (i in 0 until g.length) if (g.isTrackSupported(i)) opts.add(Triple(g, i, g.isTrackSelected(i)))
        }
        if (opts.isEmpty()) { Toast.makeText(context, "সাবটাইটেল নেই", Toast.LENGTH_SHORT).show(); return }
        val params = player.trackSelectionParameters
        val off = params.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT) || opts.none { it.third }
        // ক্রম: বন্ধ → ১ম → ২য় ... → বন্ধ
        val cur = if (off) -1 else opts.indexOfFirst { it.third }
        val nextIdx = cur + 1
        if (nextIdx >= opts.size) {
            player.trackSelectionParameters = params.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
            subtitleView.text = ""
            Toast.makeText(context, "সাবটাইটেল বন্ধ", Toast.LENGTH_SHORT).show()
        } else {
            val n = opts[nextIdx]
            player.trackSelectionParameters = params.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .setOverrideForType(TrackSelectionOverride(n.first.mediaTrackGroup, n.second)).build()
            Toast.makeText(context, trackName(n.first.getTrackFormat(n.second), "Subtitle", nextIdx), Toast.LENGTH_SHORT).show()
        }
        scheduleHide()
    }

    private fun updateProgress() {
        val d = duration()
        val t = player.currentPosition
        if (!dragging && d > 0) seek.progress = (t * 1000 / d).toInt()
        timeView.text = fmt(t) + " / " + fmt(d)
    }

    // ---------- কন্ট্রোল দেখানো/লুকানো ----------
    private fun showControls(show: Boolean) {
        val v = if (show) View.VISIBLE else View.GONE
        topBar.visibility = v
        bottomBar.visibility = v
        ui.removeCallbacks(hideRunnable)
        if (show) scheduleHide()
    }

    private fun scheduleHide() {
        ui.removeCallbacks(hideRunnable)
        topBar.visibility = View.VISIBLE
        bottomBar.visibility = View.VISIBLE
        ui.postDelayed(hideRunnable, 3500)
    }

    // ---------- বন্ধ করা ----------
    fun close() {
        if (released) return
        release()
        onClose()
    }

    fun release() {
        if (released) return
        released = true
        ui.removeCallbacksAndMessages(null)
        try { player.stop() } catch (_: Exception) {}
        try { player.clearVideoSurfaceView(surface) } catch (_: Exception) {}
        try { player.release() } catch (_: Exception) {}
    }

    // ---------- সাহায্যকারী ----------
    private fun displayName(uri: Uri): String = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: (uri.lastPathSegment ?: "media")
    } catch (_: Exception) { uri.lastPathSegment ?: "media" }

    private fun button(label: String, size: Float, onClick: () -> Unit) = TextView(context).apply {
        text = label; setTextColor(Color.WHITE); textSize = size; typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { onClick() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun fmt(ms: Long): String {
        if (ms <= 0) return "00:00"
        val s = ms / 1000
        val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }
}
